package com.promineotech.jeep.entity;

public enum JeepModel {
  WRANGLER, GRAND_CHEROKEE, CHEROKEE, COMPASS, RENEGADE, GLADIATOR, WRANGLER_4XE
}
