package com.promineotech.jeep.controller.support;

public class FetchJeepTestSupport extends BaseTest {

}
